<?php 

include "config.php";

  if (isset($_POST['submit'])) {

    $name = $_POST['name'];

    $department = $_POST['department'];

    $sql = "INSERT INTO `employee_department`(`name`, `department`) VALUES ('$name','$department')";

    $result = $conn->query($sql);

    if ($result == TRUE) {

      echo "New department record created successfully.
            Return to the previous page or exit.";

    }else{

      echo "Error:". $sql . "<br>". $conn->error;

    } 

    $conn->close(); 

  }

?>
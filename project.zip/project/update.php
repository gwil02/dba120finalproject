<?php 

include "config.php";

    if (isset($_POST['update'])) {

        $name = $_POST['name'];

        $user_id = $_POST['user_id'];

        $phone = $_POST['phone'];

        $country  = $_POST['country'];

        $email = $_POST['email'];

        $sql = "UPDATE `employee_info` SET `name`='$name',`phone`='$phone',`country`='$country',`email`='$email' WHERE `id`='$user_id'"; 

        $result = $conn->query($sql); 

        if ($result == TRUE) {

            echo "Record updated successfully.";

        }else{

            echo "Error:" . $sql . "<br>" . $conn->error;

        }

    } 

if (isset($_GET['id'])) {

    $user_id = $_GET['id']; 

    $sql = "SELECT * FROM `employee_info` WHERE `id`='$user_id'";

    $result = $conn->query($sql); 

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {

            $name = $row['name'];

            $phone = $row['phone'];

            $country  = $row['country'];

            $email = $row['email'];

            $id = $row['id'];

        } 

    ?>

        <h2>Employee Info Update Form</h2>

        <form action="" method="post">

          <fieldset>

            <legend>Employee info:</legend>

            Name:<br>

            <input type="name" name="name" value="<?php echo $name; ?>">

            <input type="hidden" name="user_id" value="<?php echo $id; ?>">

            <br>

            Phone:<br>

            <input type="phone" name="phone" value="<?php echo $phone; ?>">

            <br>

            Country:<br>

            <input type="country" name="country" value="<?php echo $country; ?>">

            <br>

            Email:<br>

            <input type="email" name="email" value="<?php echo $email; ?>">

            <br><br>

            <input type="submit" value="Update" name="update">
            

          </fieldset>

        </form> 

        </body>

        </html> 

    <?php

    } else{ 

        header('Location: view.php');

    } 

}

?> 
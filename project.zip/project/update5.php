<?php 

include "config.php";

    if (isset($_POST['update'])) {

        $name = $_POST['name'];

        $user_id = $_POST['user_id'];

        $tenure = $_POST['tenure'];

        $sql = "UPDATE `employee_tenure` SET `name`='$name',`tenure`='$tenure' WHERE `id`='$user_id'"; 

        $result = $conn->query($sql); 

        if ($result == TRUE) {

            echo "Employee tenure updated successfully.";

        }else{

            echo "Error:" . $sql . "<br>" . $conn->error;

        }

    } 

if (isset($_GET['id'])) {

    $user_id = $_GET['id']; 

    $sql = "SELECT * FROM `employee_tenure` WHERE `id`='$user_id'";

    $result = $conn->query($sql); 

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {

            $name = $row['name'];

            $tenure = $row['tenure'];

            $id = $row['id'];

        } 

    ?>

        <h2>Employee Tenure Update Form</h2>

        <form action="" method="post">

          <fieldset>

            <legend>Employee info:</legend>

            Name:<br>

            <input type="name" name="name" value="<?php echo $name; ?>">

            <input type="hidden" name="user_id" value="<?php echo $id; ?>">

            <br>

            Employee Tenure:<br>

            <input type="employee_tenure" name="tenure" value="<?php echo $tenure; ?>">

            <br><br>

            <input type="submit" value="Update" name="update">

          </fieldset>

        </form> 

        </body>

        </html> 

    <?php

    } else{ 

        header('Location: view5.php');

    } 

}

?> 
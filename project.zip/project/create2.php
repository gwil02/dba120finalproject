<?php 

include "config.php";

  if (isset($_POST['submit'])) {

    $name = $_POST['name'];

    $employeeID = $_POST['employee_id'];

    $sql = "INSERT INTO `employee_id`(`name`, `employee_id`) VALUES ('$name','$employeeID')";

    $result = $conn->query($sql);

    if ($result == TRUE) {

      echo "New employee ID created successfully.
            Return to the previous page or exit.";

    }else{

      echo "Error:". $sql . "<br>". $conn->error;

    } 

    $conn->close(); 

  }

?>

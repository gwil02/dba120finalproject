<?php 

include "config.php";

  if (isset($_POST['submit'])) {

    $name = $_POST['name'];

    $tenure = $_POST['tenure'];

    $sql = "INSERT INTO `employee_tenure`(`name`, `tenure`) VALUES ('$name','$tenure')";

    $result = $conn->query($sql);

    if ($result == TRUE) {

      echo "New tenure record created successfully.
            Return to the previous page or exit.";

    }else{

      echo "Error:". $sql . "<br>". $conn->error;

    } 

    $conn->close(); 

  }

?>
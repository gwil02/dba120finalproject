<?php 

include "config.php";

  if (isset($_POST['submit'])) {

    $name = $_POST['name'];

    $phone = $_POST['phone'];

    $country = $_POST['country'];

    $email = $_POST['email'];

    $sql = "INSERT INTO `employee_info`(`name`, `phone`, `country`, `email`) VALUES ('$name','$phone','$country','$email')";

    $result = $conn->query($sql);

    if ($result == TRUE) {

      echo "New employee info created successfully.
            Return to the previous page or exit.";

    }else{

      echo "Error:". $sql . "<br>". $conn->error;

    } 

    $conn->close(); 

  }

?>


<?php 

include "config.php";

    if (isset($_POST['update'])) {

        $name = $_POST['name'];

        $user_id = $_POST['user_id'];

        $employee_id = $_POST['employee_id'];

        $sql = "UPDATE `employee_id` SET `name`='$name',`employee_id`='$employee_id' WHERE `id`='$user_id'"; 

        $result = $conn->query($sql); 

        if ($result == TRUE) {

            echo "Employee ID updated successfully.";

        }else{

            echo "Error:" . $sql . "<br>" . $conn->error;

        }

    } 

if (isset($_GET['id'])) {

    $user_id = $_GET['id']; 

    $sql = "SELECT * FROM `employee_id` WHERE `id`='$user_id'";

    $result = $conn->query($sql); 

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {

            $name = $row['name'];

            $employee_id = $row['employee_id'];

            $id = $row['id'];

        } 

    ?>

        <h2>Employee Info Update Form</h2>

        <form action="" method="post">

          <fieldset>

            <legend>Employee info:</legend>

            Name:<br>

            <input type="name" name="name" value="<?php echo $name; ?>">

            <input type="hidden" name="user_id" value="<?php echo $id; ?>">

            <br>

            Employee ID:<br>

            <input type="employee_id" name="employee_id" value="<?php echo $employee_id; ?>">

            <br>

          </fieldset>

        </form> 

        </body>

        </html> 

    <?php

    } else{ 

        header('Location: view2.php');

    } 

}

?> 
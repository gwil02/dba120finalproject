<?php 

include "config.php";

  if (isset($_POST['submit'])) {

    $name = $_POST['name'];

    $department = $_POST['department'];

    $benefits = $_POST['benefits']

    $sql = "INSERT INTO `employee_benefits`(`name`, `department`, `benefits`) VALUES ('$name','$department','$benefits')";

    $result = $conn->query($sql);

    if ($result == TRUE) {

      echo "New benefits record created successfully.
            Return to the previous page or exit.";

    }else{

      echo "Error:". $sql . "<br>". $conn->error;

    } 

    $conn->close(); 

  }

?>